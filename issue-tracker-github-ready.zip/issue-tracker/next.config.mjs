/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: false, // Prevents double invocation issues during Drag-and-drop animation
};

export default nextConfig;
