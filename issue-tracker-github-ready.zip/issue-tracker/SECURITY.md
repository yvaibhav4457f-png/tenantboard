# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.0.x   | :white_check_mark: |

---

## Multi-Tenancy Security Model

This application implements multi-tenant boundary isolation. Security considerations include:
- **Tenant Data Isolation**: Database queries must always be filtered by `organizationId`.
- **Role-Based Access Control (RBAC)**: Enforced via `verifyTenantAccess` at the Server Action boundary.
- **Admin Demotion Protection**: The system prevents demoting or deleting the last remaining `ADMIN` in an organization.

---

## Reporting a Vulnerability

If you discover a security vulnerability or multi-tenant boundary leak, please report it responsibly:
- **Email**: `security@example.com`
- Please do **not** open a public issue.
- Include reproduction steps and payload demonstrations where applicable.
- We aim to acknowledge reports within 48 hours.
