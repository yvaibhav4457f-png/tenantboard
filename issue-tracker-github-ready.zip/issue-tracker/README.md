# Production Multi-Tenant RBAC Issue Tracker (Linear / Jira Alternative)

A production-ready, multi-tenant Role-Based Access Control (RBAC) Project Management and Issue Tracking system built with Next.js 14 (App Router), TypeScript, Tailwind CSS, Prisma ORM, and PostgreSQL. Features zero-leakage data isolation, optimistic drag-and-drop Kanban boards, markdown issue authoring, comment threads, and audit activity streams.

[![CI](https://github.com/<your-username>/issue-tracker/actions/workflows/ci.yml/badge.svg)](https://github.com/<your-username>/issue-tracker/actions/workflows/ci.yml)
![Next.js 14](https://img.shields.io/badge/Next.js-14-black) ![License: MIT](https://img.shields.io/badge/license-MIT-blue)

---

## 1. System Architecture Diagram

```mermaid
flowchart TD
    subgraph Client ["Client Browser (Next.js 14 App Router)"]
        UI["Modern Glassmorphic UI\n(Tailwind CSS + Lucide)"]
        DND["@hello-pangea/dnd\nOptimistic Kanban Drag & Drop"]
        Modal["Markdown Issue Modal\n& Comment Threads"]
    end

    subgraph SecurityLayer ["Security & Multi-Tenancy Boundary"]
        Session["NextAuth.js Session\n(JWT with Memberships)"]
        TenantGuard["verifyTenantAccess(orgSlug, requiredRole)\nStrict Tenant & Role Guard"]
    end

    subgraph Backend ["Next.js Server Actions & API Handlers"]
        IssueActions["Issue Actions\n(create, move, edit, delete)"]
        MemberActions["Member & Role Actions\n(invite, updateRole, remove)"]
        ProjectActions["Project Actions\n(createProject)"]
        AuditLogger["ActivityLog & Audit Tracker"]
    end

    subgraph Database ["PostgreSQL 16 Multi-Tenant Schema"]
        direction TB
        Orgs["organizations (Tenant Core)"]
        Members["organization_members (RBAC: ADMIN | MEMBER | VIEWER)"]
        Projects["projects (organization_id FK)"]
        Issues["issues (organization_id FK + kanbanOrder)"]
        Comments["task_comments (issue_id + author_id)"]
        Audit["activity_logs (organization_id + actor_id)"]

        Orgs --> Members
        Orgs --> Projects
        Orgs --> Issues
        Projects --> Issues
        Issues --> Comments
        Orgs --> Audit
    end

    UI --> Session
    Session --> TenantGuard
    TenantGuard --> IssueActions
    TenantGuard --> MemberActions
    TenantGuard --> ProjectActions
    IssueActions --> AuditLogger
    MemberActions --> AuditLogger
    IssueActions --> Issues
    MemberActions --> Members
    ProjectActions --> Projects
    AuditLogger --> Audit
```

---

## 2. Multi-Tenancy & Data Isolation Model

1. **Row-Level Organization Scoping**:
   - Every core database entity (`Project`, `Issue`, `ActivityLog`) stores an explicit `organizationId` foreign key with `ON DELETE CASCADE`.
   - Compound indexes: `[organizationId, status]`, `[organizationId, key]`, and `[projectId, status, kanbanOrder]` guarantee ultra-fast lookups with zero cross-tenant query contamination.
2. **Backend Security Boundary (`verifyTenantAccess`)**:
   - Server Actions do not trust parameters supplied by the client.
   - Any query or mutation validates that the authenticated `userId` has an active `OrganizationMember` record matching the target tenant.
   - Cross-tenant queries are blocked with a `TenantSecurityError` (403 Forbidden).

---

## 3. RBAC Permissions Matrix

| Feature / Action | ADMIN | MEMBER | VIEWER |
| :--- | :---: | :---: | :---: |
| **Manage Org Settings & Slug** | ✅ | ❌ | ❌ |
| **Invite Members & Change Roles** | ✅ | ❌ | ❌ |
| **Remove Members (Safe Admin protection)** | ✅ | ❌ | ❌ |
| **Create Projects** | ✅ | ✅ | ❌ |
| **Create & Update Issues** | ✅ | ✅ | ❌ |
| **Drag & Drop Kanban Status Reordering** | ✅ | ✅ | ❌ (Read-only) |
| **Add / Delete Issue Comments** | ✅ (all) | ✅ (own) | ❌ |
| **View Kanban Boards & Projects** | ✅ | ✅ | ✅ |
| **Inspect Audit Activity Logs** | ✅ | ✅ | ✅ |

---

## 4. Pre-Seeded Demo Accounts

All pre-seeded demo accounts use the default password: **`password123`**

| Persona | Email | Acme Corp (`acme-corp`) | Starlight Dynamics (`starlight`) |
| :--- | :--- | :--- | :--- |
| **Alex Vance** | `alex@acme.inc` | **`ADMIN`** (Full control) | **`VIEWER`** (Read-only) |
| **Sarah Connor** | `sarah@acme.inc` | **`MEMBER`** (Tasks & DnD) | **`ADMIN`** (Full control) |
| **Victor Stone** | `victor@acme.inc` | **`VIEWER`** (Audit & read-only) | *Not a member* (Forbidden) |

> 💡 **Notice**: The login page includes **One-Click Demo Persona buttons** to instantly switch between Admin, Member, and Viewer roles!

---

## 5. Local Setup & Quickstart Guide

### Prerequisites
- Node.js >= 18.x (tested on v20 & v24)
- Docker Desktop (for local PostgreSQL instance) or an active PostgreSQL database

### Step 1: Clone and Install Dependencies
```bash
cd issue-tracker
npm install
```

### Step 2: Configure Environment Variables
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Default `.env` configuration:
```env
# PostgreSQL connection string
DATABASE_URL="postgresql://postgres:postgrespassword@localhost:5432/issuetracker?schema=public"

# NextAuth configuration
NEXTAUTH_URL="http://localhost:3000"
# Generate your own: openssl rand -base64 32
NEXTAUTH_SECRET="replace-me"
```

### Step 3: Launch PostgreSQL with Docker
Start the included PostgreSQL container:
```bash
docker compose up -d
```
Verify the container is healthy:
```bash
docker ps
```

### Step 4: Run Prisma Migrations and Seed
Initialize the PostgreSQL database schema and seed demo organizations, projects, and issues:
```bash
# Push schema to database
npm run db:push

# Seed tenants, members, and issues
npm run db:seed
```

### Step 5: Start the Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 6. Project Structure

```text
issue-tracker/
├── docker-compose.yml              # Local PostgreSQL 16 container setup
├── prisma/
│   ├── schema.prisma               # Multi-tenant PostgreSQL relational schema
│   └── seed.ts                     # Seeding script with demo tenants, users & issues
├── src/
│   ├── actions/
│   │   ├── issues.ts               # Server Actions: create, move, update, delete, comments
│   │   ├── members.ts              # Server Actions: invite, update role, remove
│   │   └── projects.ts             # Server Actions: create project
│   ├── app/
│   │   ├── (auth)/login/page.tsx   # Login page with quick persona switcher
│   │   ├── (dashboard)/[orgSlug]/
│   │   │   ├── layout.tsx          # Tenant Security Guard, Navbar & Sidebar
│   │   │   ├── page.tsx            # Organization Overview & metrics
│   │   │   ├── members/page.tsx    # Member Management & RBAC roles
│   │   │   └── projects/[projectKey]/board/page.tsx # Interactive Kanban Board
│   │   ├── api/auth/[...nextauth]/ # NextAuth Route Handler
│   │   ├── globals.css             # Glassmorphic dark styling & DnD effects
│   │   └── layout.tsx              # Root HTML & AuthProvider
│   ├── components/
│   │   ├── board/
│   │   │   ├── KanbanBoard.tsx     # DnD context with optimistic local state
│   │   │   ├── KanbanColumn.tsx    # Droppable column container
│   │   │   └── KanbanCard.tsx      # Draggable card with priority & assignee badges
│   │   ├── issues/
│   │   │   └── IssueModal.tsx      # Markdown editor, comments, and audit timeline
│   │   ├── layout/
│   │   │   ├── Navbar.tsx          # Org switcher & RBAC role badge
│   │   │   └── Sidebar.tsx         # Projects navigation & creator
│   │   └── members/
│   │       └── MemberManagement.tsx # Member invitation & role changing table
│   └── lib/
│       ├── auth.ts                 # NextAuth credentials provider
│       ├── db.ts                   # Singleton Prisma client
│       ├── rbac.ts                 # Role matrix assertions (hasPermission)
│       ├── tenant.ts               # verifyTenantAccess security helper
│       └── utils.ts                # Priority/Status styling tokens
└── README.md                       # Architecture & Documentation
```

---

## 7. Key Features Demonstrated

1. **Fractional Indexing for Seamless Drag & Drop**:
   - Issues are ordered by a floating-point `kanbanOrder`. Moving an issue between two items calculates `(prevOrder + nextOrder) / 2` without needing expensive table-wide updates.
2. **Audit Logging & Activity Tracking**:
   - Every issue creation, status transition, priority edit, comment, and member role update is recorded in `activity_logs` with actor timestamps and JSON change diffs.
3. **Safe Admin Guard**:
   - Member management prevents demoting or removing the last remaining `ADMIN` in an organization.

---

## 8. Scripts

| Command | Purpose |
| :--- | :--- |
| `npm run dev` | Start the dev server |
| `npm run build` | `prisma generate` + production build |
| `npm run typecheck` | TypeScript check (`tsc --noEmit`) |
| `npm run db:push` / `db:seed` / `db:studio` | Schema sync, demo data, Prisma Studio |

## 9. Contributing & Security

See [CONTRIBUTING.md](CONTRIBUTING.md) and [SECURITY.md](SECURITY.md). Licensed under the [MIT License](LICENSE).

> ⚠️ The demo accounts and `password123` are for local evaluation only. Remove the seed script and set a strong `NEXTAUTH_SECRET` before any real deployment.
