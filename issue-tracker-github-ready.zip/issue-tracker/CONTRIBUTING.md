# Contributing to Linear RBAC Issue Tracker

Thank you for your interest in contributing! We welcome bug fixes, documentation improvements, and architectural suggestions.

---

## 🛠️ Development Workflow

### 1. Prerequisites
- **Node.js**: `v18.x` or higher (recommended: `v20.x`)
- **Git**
- **Docker** (optional, only if testing against PostgreSQL locally)

### 2. Fork & Clone
```bash
git clone https://github.com/<your-username>/issue-tracker.git
cd issue-tracker
```

### 3. Setup Environment
```bash
cp .env.example .env
npm install
npm run db:push
npm run db:seed
npm run dev
```

### 4. Branching Model & Commit Conventions
We adhere to [Conventional Commits](https://www.conventionalcommits.org/):
- `feat:` Adds a new user-facing feature
- `fix:` Patches a bug or regression
- `refactor:` Code restructuring without functional changes
- `perf:` Performance optimizations (e.g. index additions, query caching)
- `docs:` Documentation improvements
- `chore:` Dependency bumps, CI updates

---

## 🔒 Multi-Tenant Security Guidelines

When adding new queries, models, or Server Actions, you **must** adhere to our tenant isolation principles:

1. **Explicit Tenant Scoping**: Every new model must have an explicit `organizationId` foreign key with cascade deletion.
2. **Server-Side Validation**: Never trust client-provided IDs. Always call `verifyTenantAccess(orgSlug, requiredPermission)` before querying or mutating data.
3. **Audit Trails**: Every state mutation (task status changes, role assignments) should log an event in `ActivityLog`.

---

## 🧪 Pre-Commit Verification

Before opening a pull request, ensure the following pass locally with zero errors:

```bash
# Type-checking
npm run typecheck

# Production build
npm run build
```
