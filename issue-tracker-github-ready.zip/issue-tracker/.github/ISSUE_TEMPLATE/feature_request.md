---
name: Feature request
about: Suggest an improvement
labels: enhancement
---

**Problem you want solved**

**Proposed solution**

**RBAC impact** (which roles should have access?)
