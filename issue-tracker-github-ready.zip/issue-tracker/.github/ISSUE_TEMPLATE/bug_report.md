---
name: Bug report
about: Something isn't working
labels: bug
---

**What happened?**

**Steps to reproduce**
1.

**Expected behavior**

**Environment** (Node version, OS, database)

> Security issue or tenant-isolation leak? Do NOT open a public issue. See SECURITY.md.
