## Summary
<!-- What does this change and why? -->

## Type
- [ ] feat  - [ ] fix  - [ ] refactor  - [ ] perf  - [ ] docs  - [ ] chore

## Multi-tenant security checklist
- [ ] New models have an `organizationId` FK with cascade delete
- [ ] Server Actions call `verifyTenantAccess(orgSlug, permission)` before reading/writing
- [ ] State mutations write an `ActivityLog` entry
- [ ] `npx tsc --noEmit` and `npm run build` pass
